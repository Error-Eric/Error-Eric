import os 
import sys
import time
if __name__ == "__main__":
    if sys.argv[1] not in "12345": 
        raise ValueError("WTF")
    t1 = time.perf_counter_ns()
    res1 = os.system(f"g++ T{sys.argv[1]}.cpp -o my.exe -std=c++11 -Wall")
    t2 = time.perf_counter_ns()
    if res1 == 0: print(f"Compliation {(t2 - t1)/1e6}ms")
    else: print("CE"); exit(1)
    res2 = os.system(".\\my.exe <in.txt >out.txt")
    t3 = time.perf_counter_ns()
    if res2 == 0: print(f"Running {(t3 - t2)/1e6}ms")
    else: print(f"RE {(t3 - t2)/1e6}ms")