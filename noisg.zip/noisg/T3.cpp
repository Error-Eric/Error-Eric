#include<iostream>
#include<algorithm>
#include<set>
#include<vector>

using namespace std;

#define int long long

int n, q, l, r, x, sum, countt;
set<pair<int, int> > snacks; // delicious = first, number = second
vector<int> initial;
vector<pair<int, int> > toerase;


signed main(){
    ios::sync_with_stdio(0),
    cin.tie(0), cout.tie(0);
    cin >> n >> q;
    for(int i = 1; i <= n; i++)
        cin >> x, initial.push_back(x), sum += x;
    cout << sum << endl;
    sort(initial.begin(), initial.end()), l = initial.front(), r = 0;
    for(int i = 0; i <= n; i++){
        if(i != n && initial[i] == l) ++ r;
        else snacks.insert({l, r}), l = initial[i - (i==n)], r= 1;
    }
    for(int qid = 1; qid <= q; qid++){
        cin >> l >> r >> x, countt = 0, toerase.clear();
        for(auto it = snacks.upper_bound({l, -1}); it != snacks.end(); ++it){
            if((*it).first > r) break;
            else toerase.push_back(*it);
        }
        if(x < l || x > r){
            auto it = snacks.upper_bound({x, -1});
            if(it != snacks.end() && (*it).first == x)
                toerase.push_back(*it);
        }
        for(auto ei: toerase){
            snacks.erase(snacks.find(ei)),
            sum -= ei.first * ei.second, countt += ei.second;
            //cout << "<" << ei.first << "," << ei.second << ">" <<  " ";
        }
        snacks.insert({x, countt});
        sum += countt * x;
        cout << sum <<endl;
    }
}
