#include<iostream>
#include<algorithm>
#include<numeric>
using namespace std;
// 15 pts solution
#define int long long
const int _= 2.1e3;
int h, w, k, ans;
int l[_], r[_], c[_], add[_];

int subtask1(){
    if((*min_element(c+1, c+ h + 1)) <= k) return 0;
    for(int i = 1; i <= h; i++){
        ++add[l[i]], --add[r[i]+1];
    }
    for(int i =1 ;i <= w; i++){
        ans += ((add[i] += add[i-1]) == 0);
    }
    cout << ans << endl;
    return 1;
}
int subtask2(){
    for(int i = 1; i <= h; i++)
        if(l[i] != r[i]) return 0;
    for(int i = 1; i <= h; i++)
        add[l[i]] += c[i];
    sort(add + 1, add + w + 1);
    for(int i =1; i <= w && k >=0; i++){
        if(k - add[i] >= 0) k-= add[i], ++ans;
        //else k = -1;
    }
    cout << ans - (ans == w) << endl;
    return 1;
}
bool ok(int p, int q){
    int totc = 0;
    for(int j = 0; j < h-1; j++)
        if(p&(1<<j)) totc += c[j+1];
    //cout <<"?" << endl;
    return (totc + (q!=l[h])* c[h]) <=k;
}
int emp(int p, int q){
    for(int i = 1; i <=w; i++)
        add[i] = 0;
    for(int j = 0; j < h-1; j++)
        if((p&(1<<j)) == 0)
            for(int ii = l[j+1]; ii <= r[j+1]; ii ++)
                add[ii] ++;
    for(int i = q; i <= q - l[h] + r[h]; i++)
        add[i] ++;
    int ret = 0;
    for(int i = 1; i <= w; i++)
        if(add[i] == 0) ++ ret;
    return ret;
}
int subtask3(){
    if(h > 18 || w > 18) return 0;
    int leni = 1;
    for(int i = 2; i <= h; i++){
        if(r[i] - l[i] > r[leni] - l[leni] )
            leni = i;
    }
    swap(l[h], l[leni]), swap(r[h], r[leni]), swap(c[h], c[leni]);
    //cout <<"??" << endl;
    for(int i = 0; i <(1<<(h-1)); i++){
        // select 1-17
        for(int j = 1; j -l[h] + r[h] <= w; j++){
            if(ok(i, j)) ans = max(ans, emp(i, j));
        }
    }
    cout << ans<< endl;
    return 1;
}

signed main(){
    ios::sync_with_stdio(0),
    cin.tie(0), cout.tie(0);
    cin >> h >> w >> k;
    for(int i = 1; i <= h; i++)
        cin >> l[i] >> r[i] >> c[i];
    if(subtask1())return 0;
    else if(subtask2()) return 0;
    else if(subtask3()) return 0;

}
