#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const int _= 4.1e5;
int n, m, u, v, s[_], ans[_];
vector<int> ord[_], e[_];
struct nodeinfo{
    nodeinfo(int ff = 0, int mi = 0x7fffffff, int mx = -1, int to = 0){
        fail = ff, mino = mi, maxo = mx, toto = to;
    }
    int fail, mino, maxo, toto;
}f[_];
/*
void testnodeinfo(){

    for(int i = 1; i <= n; i++)
        if(f[i].mino < 1e9)
            printf("i=%d<%d, %d, %d>(%d)%c",i,f[i].mino, f[i].maxo, f[i].toto, f[i].fail, " \n"[i==n]);
        else printf("i=%d<null>(%d)%c", i, f[i].fail," \n"[i==n]);
}
*/
void update(int o, int fa){
    //printf("update(%d %d)\n", o, fa), testnodeinfo();
    if(!ord[o].empty())
        f[o] = nodeinfo(0, ord[o].front(), ord[o].back(), ord[o].size());
    else f[o] = nodeinfo();
    for(int to : e[o]) if(to != fa){
        f[o].fail += (f[to].fail!=0);
        f[o].mino = min(f[to].mino, f[o].mino);
        f[o].maxo = max(f[to].maxo, f[o].maxo);
        f[o].toto += f[to].toto;

    }
    if(f[o].toto!= 0 && f[o].toto != f[o].maxo - f[o].mino + 1 && f[o].maxo > f[o].mino)
        f[o].fail += 1;
}

void dfs1(int o, int fr){
    //cout << "Dfs1::" << o << "," << fr << endl;
    for(int to : e[o]) if (to != fr){
        dfs1(to, o);
    }
    update(o, fr);
}

void root(int ou, int ov){
    //printf("root[%d, %d]\n", ou, ov);

    if(ou != ov){
        // exclude ov's contribution in ou
        if(f[ou].mino == f[ov].mino || f[ou].maxo == f[ov].maxo)
            update(ou, ov);
        else
            f[ou].fail += (f[ou].toto == f[ou].maxo - f[ou].mino + 1),
            f[ou].toto -= f[ov].toto,
            f[ou].fail -= (f[ov].fail!=0),
            f[ou].fail -= (f[ou].toto == f[ou].maxo - f[ou].mino + 1);

        // include ou's contribution in ov
        //update(ov, ov);
        f[ov].fail -= (f[ov].toto != 0 && f[ov].maxo - f[ov].mino +1 != f[ov].toto && f[ov].mino < f[ov].maxo);
        f[ov].mino = min(f[ov].mino, f[ou].mino);
        f[ov].maxo = max(f[ov].maxo, f[ou].maxo);
        f[ov].toto += f[ou].toto;
        f[ov].fail += (f[ou].fail!=0);
        f[ov].fail += (f[ov].toto != 0 && f[ov].maxo - f[ov].mino +1 != f[ov].toto && f[ov].mino < f[ov].maxo);

    }
    //testnodeinfo();
}

void dfs2(int o, int fr){
    root(fr, o), ans[o] = (f[o].fail == 0);
    //cout << "[ROOT]" << o << endl;
    //testnodeinfo();
    for(int to : e[o]) if (to != fr)
        dfs2(to, o);
    root(o, fr);
}

int main(){
    ios::sync_with_stdio(0),
    cin.tie(0), cout.tie(0);
    cin >> n >> m;
    for(int i = 1; i < n; i++)
        cin >> u >> v, e[u].push_back(v), e[v].push_back(u);
    for(int i = 1; i <= m; i++)
        cin >> s[i], ord[s[i]].push_back(i);
    dfs1(s[1], s[1]); //testnodeinfo();
    dfs2(s[1], s[1]);
    for(int i = 1; i <= n; i++)
        cout << ans[i] << endl;
}
